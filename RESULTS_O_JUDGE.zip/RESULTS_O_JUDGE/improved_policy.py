"""Custom policy entrypoint for competition — v6 with normalization.

Usage with eval.py:
  python eval.py difficulty=easy obs_mode=rgb \
      policy=improved_policy:load_improved_dp_rgb \
      checkpoint=checkpoints/best.pt \
      eval_config=conf/eval/default.yaml
"""
import torch, sys, os, json
import numpy as np


class ImprovedDPRgbPolicy:
    def __init__(self, agent, obs_horizon, act_horizon, device, num_inference_steps=16):
        self.agent = agent.to(device).eval()
        self.agent.noise_scheduler.set_timesteps(num_inference_steps)
        self.obs_horizon = obs_horizon
        self.act_horizon = act_horizon
        self.device = device
        self.prev = None
        self.action_queue = []

    @torch.no_grad()
    def act(self, obs, deterministic=True):
        if len(self.action_queue) > 0:
            action = self.action_queue.pop(0)
            self.prev = {"state": obs["state"].float().to(self.device), "rgb": obs["rgb"].to(self.device)}
            return action.clamp(-1.0, 1.0)
        state = obs["state"].float().to(self.device)
        rgb   = obs["rgb"].to(self.device)
        cur = {"state": state, "rgb": rgb}
        if self.prev is None or self.prev["state"].shape != state.shape:
            self.prev = cur
        obs_seq = {
            "state": torch.stack([self.prev["state"], state], 1),
            "rgb":   torch.stack([self.prev["rgb"],   rgb],   1),
        }
        self.prev = cur
        aseq = self.agent.get_action(obs_seq, num_inference_steps=self.agent.noise_scheduler.num_inference_steps)
        for i in range(1, aseq.shape[1]):
            self.action_queue.append(aseq[:, i])
        return aseq[:, 0].clamp(-1.0, 1.0)


def load_improved_dp_rgb(checkpoint, sample_obs, action_space, device):
    solve_path = os.path.dirname(os.path.abspath(__file__))
    if solve_path not in sys.path:
        sys.path.insert(0, solve_path)

    try:
        from solve_marso_hack_v6 import Agent
    except Exception:
        try:
            from _agent_loader import Agent
        except Exception as e:
            raise ImportError(
                f"Cannot import Agent: {e}. Make sure solve_marso_hack_v6.py is on PYTHONPATH."
            )

    state_dim = sample_obs["state"].shape[1]
    act_dim   = action_space.shape[0]

    ckpt = torch.load(checkpoint, map_location=device, weights_only=False)
    am  = ckpt.get("action_mean", None)
    ast = ckpt.get("action_std",  None)
    sm  = ckpt.get("state_mean",  None)
    sst = ckpt.get("state_std",   None)

    if am is None:
        for ns_path in [
            os.path.join(os.path.dirname(checkpoint), "..", "norm_stats.json"),
            os.path.join(solve_path, "norm_stats.json"),
        ]:
            if os.path.exists(ns_path):
                with open(ns_path) as f:
                    ns = json.load(f)
                am  = np.array(ns["action_mean"])
                ast = np.array(ns["action_std"])
                sm  = np.array(ns["state_mean"])
                sst = np.array(ns["state_std"])
                break

    agent = Agent(
        state_dim, act_dim,
        2, 8, 16,
        "resnet18", 32, [128, 256, 512], 64, 8,
        False, am, ast, sm, sst,
    )
    agent.load_state_dict(ckpt.get("ema_agent", ckpt.get("agent")))
    return ImprovedDPRgbPolicy(agent, 2, 8, device)
