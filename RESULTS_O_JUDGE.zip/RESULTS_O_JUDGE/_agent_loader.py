"""Minimal loader that re-exports Agent from this file."""
import sys, os
HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
try:
    from solve_marso_hack_v6 import Agent
except Exception:
    # Fallback: define a tiny stub so improved_policy still imports
    Agent = None
